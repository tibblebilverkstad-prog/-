export default function App() {
  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>Tibbles Bilverkstad</h1>
      <p>Vi lagar bilar snabbt och billigt.</p>

      <h2>Tjänster</h2>
      <ul>
        <li>Service</li>
        <li>Däckbyte</li>
        <li>Reparation</li>
      </ul>

      <h2>Kontakt</h2>
      <p>Telefon: 070-123 45 67</p>

      <button onClick={() => alert("Bokning kommer snart!")}>
        Boka tid
      </button>
    </div>
  );
}
