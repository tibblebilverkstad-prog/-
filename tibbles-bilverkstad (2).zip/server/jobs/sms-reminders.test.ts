import { describe, it, expect, vi, beforeEach } from "vitest";
import sendSMSReminders from "./sms-reminders";

// Mock the database module
vi.mock("../db", () => ({
  getAllBookings: vi.fn().mockResolvedValue([
    {
      id: 1,
      customerName: "John Doe",
      customerPhone: "0701234567",
      bookingDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      bookingTime: "14:00",
      carModel: "BMW X5",
      services: "Service",
      status: "confirmed",
    },
    {
      id: 2,
      customerName: "Jane Smith",
      customerPhone: "0702345678",
      bookingDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      bookingTime: "15:00",
      carModel: "Volvo V90",
      services: "Däckbyte",
      status: "confirmed",
    },
  ]),
}));

// Mock the notification module
vi.mock("../_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

describe("SMS Reminder Job", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should find bookings for tomorrow", async () => {
    await sendSMSReminders();
    // Job should complete without errors
    expect(true).toBe(true);
  });

  it("should handle multiple bookings", async () => {
    await sendSMSReminders();
    // Job should process all bookings
    expect(true).toBe(true);
  });

  it("should not crash if no bookings found", async () => {
    vi.resetModules();
    vi.doMock("../db", () => ({
      getAllBookings: vi.fn().mockResolvedValue([]),
    }));

    await sendSMSReminders();
    expect(true).toBe(true);
  });

  it("should handle errors gracefully", async () => {
    vi.resetModules();
    vi.doMock("../db", () => ({
      getAllBookings: vi.fn().mockRejectedValue(new Error("Database error")),
    }));

    // Should not throw
    try {
      await sendSMSReminders();
      expect(true).toBe(true);
    } catch (error) {
      expect.fail("Should handle errors gracefully");
    }
  });

  it("should only send reminders for tomorrow's bookings", async () => {
    await sendSMSReminders();
    // Job should filter by date correctly
    expect(true).toBe(true);
  });
});
