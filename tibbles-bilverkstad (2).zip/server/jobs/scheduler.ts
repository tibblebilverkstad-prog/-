/**
 * Job Scheduler
 * 
 * This module sets up scheduled jobs for recurring tasks like SMS reminders.
 * 
 * To enable real scheduling, install node-cron:
 * npm install node-cron
 * 
 * Then uncomment the cron setup code below.
 */

import sendSMSReminders from "./sms-reminders";

// import cron from "node-cron";

/**
 * Initialize all scheduled jobs
 */
export function initializeScheduledJobs() {
  console.log("[Scheduler] Initializing scheduled jobs...");

  // TODO: Uncomment to enable real cron scheduling
  /*
  // Run SMS reminders every day at 10:00 AM
  cron.schedule("0 10 * * *", async () => {
    console.log("[Scheduler] Running SMS reminder job at 10:00 AM");
    await sendSMSReminders();
  });

  console.log("[Scheduler] SMS reminder job scheduled for 10:00 AM daily");
  */

  // For development/testing, you can manually call the job:
  // await sendSMSReminders();

  console.log("[Scheduler] Scheduled jobs initialized");
}

export { sendSMSReminders };
