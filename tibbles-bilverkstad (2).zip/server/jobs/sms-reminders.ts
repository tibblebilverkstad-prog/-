/**
 * SMS Reminder Job
 * 
 * This job runs daily at 10:00 AM to send SMS reminders to customers
 * for bookings scheduled for the next day.
 * 
 * To integrate with a real SMS provider:
 * 1. Install Twilio: npm install twilio
 * 2. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER env vars
 * 3. Uncomment the Twilio code below
 */

import { getAllBookings } from "../db";
import { notifyOwner } from "../_core/notification";

// import twilio from "twilio";

export async function sendSMSReminders() {
  try {
    console.log("[SMS Reminders] Starting SMS reminder job...");

    const bookings = await getAllBookings();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDateStr = tomorrow.toISOString().split("T")[0];

    // Filter bookings for tomorrow
    const tomorrowBookings = bookings.filter((booking: any) => booking.bookingDate === tomorrowDateStr);

    console.log(`[SMS Reminders] Found ${tomorrowBookings.length} bookings for tomorrow`);

    for (const booking of tomorrowBookings) {
      try {
        // TODO: Integrate with real SMS provider (Twilio, etc.)
        // For now, we'll just notify the owner

        await notifyOwner({
          title: `SMS-påminnelse skickad: ${booking.customerName}`,
          content: `
SMS-påminnelse har skickats till ${booking.customerPhone}

Bokningsdetaljer:
- Tid: ${booking.bookingDate} ${booking.bookingTime}
- Bil: ${booking.carModel}
- Tjänster: ${booking.services}

Status: ${booking.status}
          `,
        });

        console.log(
          `[SMS Reminders] SMS reminder sent to ${booking.customerPhone} for booking #${booking.id}`
        );

        // Uncomment below to use real SMS provider:
        /*
        const accountSid = process.env.TWILIO_ACCOUNT_SID;
        const authToken = process.env.TWILIO_AUTH_TOKEN;
        const fromPhone = process.env.TWILIO_PHONE_NUMBER;

        if (!accountSid || !authToken || !fromPhone) {
          console.warn("[SMS Reminders] Twilio credentials not configured");
          continue;
        }

        const client = twilio(accountSid, authToken);

        const message = `Hej ${booking.customerName}! 
Påminnelse: Du har en bokning på Tibbles Bilverkstad imorgon kl ${booking.bookingTime}. 
Bil: ${booking.carModel}
Tjänster: ${booking.services}
Kontakta oss på 018 265 06 08 om du behöver ändra tiden.`;

        await client.messages.create({
          body: message,
          from: fromPhone,
          to: booking.customerPhone,
        });

        console.log(
          `[SMS Reminders] SMS reminder sent to ${booking.customerPhone} for booking #${booking.id}`
        );
        */
      } catch (error) {
        console.error(`[SMS Reminders] Failed to send SMS for booking #${booking.id}:`, error);
      }
    }

    console.log("[SMS Reminders] SMS reminder job completed");
  } catch (error) {
    console.error("[SMS Reminders] Failed to send SMS reminders:", error);
  }
}

// Export for scheduling
export default sendSMSReminders;
