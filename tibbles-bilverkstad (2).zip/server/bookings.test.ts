import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for testing
function createMockContext(isAdmin: boolean = false): TrpcContext {
  return {
    user: isAdmin
      ? {
          id: 1,
          openId: "admin-user",
          email: "admin@example.com",
          name: "Admin User",
          loginMethod: "manus",
          role: "admin",
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: new Date(),
        }
      : null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Booking System", () => {
  let createdBookingId: number;

  it("should create a new booking", async () => {
    const caller = appRouter.createCaller(createMockContext());

    const result = await caller.bookings.create({
      customerName: "John Doe",
      customerEmail: "john@example.com",
      customerPhone: "0701234567",
      carModel: "BMW X5",
      services: "Service, Däckbyte",
      message: "Snabbt tack",
      bookingDate: "2025-04-15",
      bookingTime: "14:00",
    });

    expect(result).toBeDefined();
  });

  it("should not allow non-admin users to list bookings", async () => {
    const caller = appRouter.createCaller(createMockContext(false));

    try {
      await caller.bookings.list();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      // Non-authenticated users get "Please login" error
      expect(error.message).toContain("Please login");
    }
  });

  it("should allow admin users to list bookings", async () => {
    const caller = appRouter.createCaller(createMockContext(true));

    const result = await caller.bookings.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should not allow non-admin users to update booking status", async () => {
    const caller = appRouter.createCaller(createMockContext(false));

    try {
      await caller.bookings.updateStatus({
        id: 1,
        status: "confirmed",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      // Non-authenticated users get "Please login" error
      expect(error.message).toContain("Please login");
    }
  });

  it("should validate email format on booking creation", async () => {
    const caller = appRouter.createCaller(createMockContext());

    try {
      await caller.bookings.create({
        customerName: "John Doe",
        customerEmail: "invalid-email",
        customerPhone: "0701234567",
        carModel: "BMW X5",
        services: "Service",
        bookingDate: "2025-04-15",
        bookingTime: "14:00",
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.message).toContain("email");
    }
  });

  it("should validate booking status values", async () => {
    const caller = appRouter.createCaller(createMockContext(true));

    try {
      await caller.bookings.updateStatus({
        id: 1,
        status: "invalid-status" as any,
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      // Zod validation error
      expect(error.message).toContain("Invalid option");
    }
  });
});
