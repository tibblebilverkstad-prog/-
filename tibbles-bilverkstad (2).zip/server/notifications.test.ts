import { describe, it, expect, vi, beforeEach } from "vitest";
import { sendBookingConfirmationEmail, sendBookingStatusUpdateEmail, formatBookingDetails } from "./notifications";
import type { Booking } from "../drizzle/schema";

// Mock the notification module
vi.mock("./_core/notification", () => ({
  notifyOwner: vi.fn().mockResolvedValue(true),
}));

describe("Notification System", () => {
  const mockBooking: Booking = {
    id: 1,
    customerName: "John Doe",
    customerEmail: "john@example.com",
    customerPhone: "0701234567",
    carModel: "BMW X5",
    services: "Service, Däckbyte",
    message: "Snabbt tack",
    bookingDate: "2025-04-15",
    bookingTime: "14:00",
    status: "pending",
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should send booking confirmation email", async () => {
    await sendBookingConfirmationEmail(mockBooking);
    // Function should not throw
    expect(true).toBe(true);
  });

  it("should send booking status update email", async () => {
    await sendBookingStatusUpdateEmail(mockBooking, "pending");
    // Function should not throw
    expect(true).toBe(true);
  });

  it("should format booking details correctly", () => {
    const formatted = formatBookingDetails(mockBooking);
    
    expect(formatted).toContain("Bokningsnummer: #1");
    expect(formatted).toContain("Datum: 2025-04-15");
    expect(formatted).toContain("Tid: 14:00");
    expect(formatted).toContain("Bil: BMW X5");
    expect(formatted).toContain("Tjänster: Service, Däckbyte");
    expect(formatted).toContain("Telefon: 0701234567");
  });

  it("should handle missing message in booking", () => {
    const bookingWithoutMessage: Booking = {
      ...mockBooking,
      message: null as any,
    };

    const formatted = formatBookingDetails(bookingWithoutMessage);
    expect(formatted).toBeDefined();
    expect(formatted.length).toBeGreaterThan(0);
  });

  it("should include customer details in confirmation email", async () => {
    await sendBookingConfirmationEmail(mockBooking);
    // Email should be sent successfully
    expect(true).toBe(true);
  });

  it("should handle status changes from pending to confirmed", async () => {
    const confirmedBooking: Booking = {
      ...mockBooking,
      status: "confirmed",
    };

    await sendBookingStatusUpdateEmail(confirmedBooking, "pending");
    // Email should be sent successfully
    expect(true).toBe(true);
  });

  it("should handle status changes from confirmed to completed", async () => {
    const completedBooking: Booking = {
      ...mockBooking,
      status: "completed",
    };

    await sendBookingStatusUpdateEmail(completedBooking, "confirmed");
    // Email should be sent successfully
    expect(true).toBe(true);
  });

  it("should handle cancellations", async () => {
    const cancelledBooking: Booking = {
      ...mockBooking,
      status: "cancelled",
    };

    await sendBookingStatusUpdateEmail(cancelledBooking, "pending");
    // Email should be sent successfully
    expect(true).toBe(true);
  });
});
