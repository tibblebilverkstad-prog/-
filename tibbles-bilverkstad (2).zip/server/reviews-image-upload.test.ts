import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("reviews image upload", () => {
  it("should upload an image successfully", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Create a simple base64 encoded image (1x1 pixel PNG)
    const base64Image = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

    const result = await caller.reviews.uploadImage({
      fileName: "test-car.png",
      fileData: base64Image,
      mimeType: "image/png",
    });

    expect(result.success).toBe(true);
    expect(result.url).toBeDefined();
    expect(result.url).toContain("reviews/");
  });

  it("should create a review with image URL", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.create({
      bookingId: 1,
      customerName: "John Doe",
      customerEmail: "john@example.com",
      rating: 5,
      comment: "Great service with photos!",
      services: "Service",
      carModel: "BMW X5",
      imageUrl: "https://example.com/car.jpg",
    });

    expect(result).toBeDefined();
  });

  it("should create a review without image URL", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.create({
      bookingId: 1,
      customerName: "Jane Doe",
      customerEmail: "jane@example.com",
      rating: 4,
      comment: "Good service",
      services: "Däckbyte",
      carModel: "Volvo V90",
    });

    expect(result).toBeDefined();
  });

  it("should validate image file data format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.uploadImage({
        fileName: "test.jpg",
        fileData: "", // Empty file data
        mimeType: "image/jpeg",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should handle different image formats", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const base64Image = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

    const formats = [
      { mimeType: "image/png", fileName: "test.png" },
      { mimeType: "image/jpeg", fileName: "test.jpg" },
      { mimeType: "image/webp", fileName: "test.webp" },
    ];

    for (const format of formats) {
      const result = await caller.reviews.uploadImage({
        fileName: format.fileName,
        fileData: base64Image,
        mimeType: format.mimeType,
      });

      expect(result.success).toBe(true);
      expect(result.url).toBeDefined();
    }
  });
});
