import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { createBooking, getAllBookings, getBookingById, updateBookingStatus, createReview, getApprovedReviews, getAllReviews, updateReviewStatus } from "./db";
import { sendBookingConfirmationEmail, sendBookingStatusUpdateEmail } from "./notifications";
import { lookupVehicle } from "./vehicle-lookup";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  bookings: router({
    create: publicProcedure
      .input(z.object({
        customerName: z.string(),
        customerEmail: z.string().email(),
        customerPhone: z.string(),
        carModel: z.string(),
        services: z.string(),
        message: z.string().optional(),
        bookingDate: z.string(),
        bookingTime: z.string(),
      }))
      .mutation(async ({ input }) => {
        const result = await createBooking({
          ...input,
          status: "pending",
        });

        // Send confirmation email to owner
        // Get the most recent booking for this customer
        const allBookings = await getAllBookings();
        const newBooking = allBookings[allBookings.length - 1];
        if (newBooking) {
          await sendBookingConfirmationEmail(newBooking);
        }

        return result;
      }),
    
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Only admins can view bookings");
      }
      return await getAllBookings();
    }),
    
    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can view bookings");
        }
        return await getBookingById(input.id);
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(["pending", "confirmed", "completed", "cancelled"]) }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can update bookings");
        }

        // Get the booking before updating to get the old status
        const oldBooking = await getBookingById(input.id);
        const oldStatus = oldBooking?.status || "unknown";

        // Update the status
        const result = await updateBookingStatus(input.id, input.status);

        // Send status update email to owner
        const updatedBooking = await getBookingById(input.id);
        if (updatedBooking && oldStatus !== input.status) {
          await sendBookingStatusUpdateEmail(updatedBooking, oldStatus);
        }

        return result;
      }),
  }),

  vehicles: router({
    lookup: publicProcedure
      .input(z.object({
        registrationNumber: z.string().min(1).max(10),
      }))
      .mutation(async ({ input }) => {
        return await lookupVehicle(input.registrationNumber);
      }),
  }),

  reviews: router({
    uploadImage: publicProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(),
        mimeType: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          const buffer = Buffer.from(input.fileData, 'base64');
          const timestamp = Date.now();
          const random = Math.random().toString(36).substring(2, 8);
          const fileKey = `reviews/${timestamp}-${random}-${input.fileName}`;
          const { storagePut } = await import('./storage');
          const { url } = await storagePut(fileKey, buffer, input.mimeType);
          return { url, success: true };
        } catch (error) {
          console.error('[Reviews] Image upload failed:', error);
          throw new Error('Kunde inte ladda upp bild. Försök igen senare.');
        }
      }),
    
    create: publicProcedure
      .input(z.object({
        bookingId: z.number(),
        customerName: z.string(),
        customerEmail: z.string().email(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
        services: z.string(),
        carModel: z.string(),
        imageUrl: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createReview({
          ...input,
          status: "pending",
        });
      }),
    
    listApproved: publicProcedure.query(async () => {
      return await getApprovedReviews();
    }),
    
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user?.role !== "admin") {
        throw new Error("Only admins can view all reviews");
      }
      return await getAllReviews();
    }),
    
    updateStatus: protectedProcedure
      .input(z.object({ id: z.number(), status: z.enum(["pending", "approved", "rejected"]) }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can update reviews");
        }
        return await updateReviewStatus(input.id, input.status);
      }),
  }),
});

export type AppRouter = typeof appRouter;
