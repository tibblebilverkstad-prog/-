import { notifyOwner } from "./_core/notification";
import type { Booking } from "../drizzle/schema";

/**
 * Send email confirmation to customer when they make a booking
 */
export async function sendBookingConfirmationEmail(booking: Booking) {
  try {
    // Notify the owner about the new booking
    await notifyOwner({
      title: `Ny bokning från ${booking.customerName}`,
      content: `
En ny bokning har gjorts!

Kunduppgifter:
- Namn: ${booking.customerName}
- E-post: ${booking.customerEmail}
- Telefon: ${booking.customerPhone}
- Bil: ${booking.carModel}

Bokningsdetaljer:
- Datum: ${booking.bookingDate}
- Tid: ${booking.bookingTime}
- Tjänster: ${booking.services}
${booking.message ? `- Meddelande: ${booking.message}` : ""}

Status: ${booking.status}

Gå till admin-panelen för att hantera denna bokning: /admin
      `,
    });

    console.log(`[Notifications] Booking confirmation sent for booking #${booking.id}`);
  } catch (error) {
    console.error("[Notifications] Failed to send booking confirmation:", error);
  }
}

/**
 * Send email when booking status is updated
 */
export async function sendBookingStatusUpdateEmail(booking: Booking, oldStatus: string) {
  try {
    const statusLabels: Record<string, string> = {
      pending: "Väntande",
      confirmed: "Bekräftad",
      completed: "Slutförd",
      cancelled: "Avbruten",
    };

    // Notify the owner about the status change
    await notifyOwner({
      title: `Bokningsstatus uppdaterad: ${booking.customerName}`,
      content: `
Bokningsstatus har uppdaterats!

Kunduppgifter:
- Namn: ${booking.customerName}
- E-post: ${booking.customerEmail}

Bokningsdetaljer:
- Datum: ${booking.bookingDate}
- Tid: ${booking.bookingTime}
- Bil: ${booking.carModel}

Statusändring: ${statusLabels[oldStatus] || oldStatus} → ${statusLabels[booking.status] || booking.status}

Gå till admin-panelen för mer information: /admin
      `,
    });

    console.log(`[Notifications] Status update email sent for booking #${booking.id}`);
  } catch (error) {
    console.error("[Notifications] Failed to send status update email:", error);
  }
}

/**
 * Send SMS reminder for upcoming bookings (called by scheduled job)
 * This would typically be called by a cron job or background task
 */
export async function sendSMSReminders() {
  try {
    // In a real implementation, this would:
    // 1. Query bookings for tomorrow
    // 2. Send SMS to customer phone numbers
    // 3. Log the sent reminders

    // For now, we'll just log that the function was called
    console.log("[Notifications] SMS reminder job executed");

    // TODO: Integrate with SMS provider (Twilio, etc.)
    // This would require additional configuration and API keys
  } catch (error) {
    console.error("[Notifications] Failed to send SMS reminders:", error);
  }
}

/**
 * Format booking details for email/SMS
 */
export function formatBookingDetails(booking: Booking): string {
  return `
Bokningsnummer: #${booking.id}
Datum: ${booking.bookingDate}
Tid: ${booking.bookingTime}
Bil: ${booking.carModel}
Tjänster: ${booking.services}
Telefon: ${booking.customerPhone}
  `.trim();
}
