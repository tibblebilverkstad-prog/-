import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

function createPublicContext(): TrpcContext {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("reviews", () => {
  it("should create a review with valid input", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.create({
      bookingId: 1,
      customerName: "John Doe",
      customerEmail: "john@example.com",
      rating: 5,
      comment: "Great service!",
      services: "Service",
      carModel: "BMW X5",
    });

    expect(result).toBeDefined();
  });

  it("should validate email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.create({
        bookingId: 1,
        customerName: "John Doe",
        customerEmail: "invalid-email",
        rating: 5,
        comment: "Great service!",
        services: "Service",
        carModel: "BMW X5",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should validate rating between 1-5", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.create({
        bookingId: 1,
        customerName: "John Doe",
        customerEmail: "john@example.com",
        rating: 10,
        comment: "Great service!",
        services: "Service",
        carModel: "BMW X5",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should list approved reviews publicly", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.listApproved();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should require admin role to list all reviews", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.list();
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should allow admin to list all reviews", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should require admin role to update review status", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.reviews.updateStatus({
        id: 1,
        status: "approved",
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should allow admin to update review status", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.reviews.updateStatus({
      id: 1,
      status: "approved",
    });

    expect(result).toBeDefined();
  });
});
