/*
 * BOOKING PAGE – Tibbles Bilverkstad
 * Design: Nordisk hantverk möter modern precision
 * Navy #0d1b2a | Red #c1121f | Oswald headings | Nunito Sans body
 */

import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Car, Phone, Mail, MapPin, Clock, ChevronLeft, CheckCircle, Calendar, User, Wrench, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import VehicleLookup from "@/components/VehicleLookup";

const SERVICES = [
  "Service & Oljebyte",
  "Bromsservice",
  "Däckbyte & Balansering",
  "Rekond & Biltvätt",
  "Glasskada / Rutbyte",
  "Elproblem & Diagnostik",
  "Kamrem & Vattenpump",
  "Motorrenovering",
  "Försäkringsärende",
  "Annat",
];

const TIME_SLOTS = [
  "08:00", "08:30", "09:00", "09:30", "10:00", "10:30",
  "11:00", "11:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30",
];

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0d1b2a] shadow-2xl">
      <div className="container flex items-center justify-between h-16">
        <Link href="/">
          <a className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#c1121f] flex items-center justify-center">
              <Car size={18} className="text-white" />
            </div>
            <div>
              <span className="font-['Oswald'] text-white font-bold text-lg tracking-widest uppercase">Tibbles</span>
              <span className="font-['Oswald'] text-[#c1121f] font-bold text-lg tracking-widest uppercase ml-1">Bilverkstad</span>
            </div>
          </a>
        </Link>
        <Link href="/">
          <a className="flex items-center gap-2 font-['Nunito_Sans'] text-white/70 hover:text-white text-sm transition-colors">
            <ChevronLeft size={16} />
            Tillbaka till startsidan
          </a>
        </Link>
      </div>
    </nav>
  );
}

export default function Booking() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    carMake: "",
    carModel: "",
    carYear: "",
    regNumber: "",
    service: "",
    date: "",
    time: "",
    message: "",
  });

  const update = (field: string, value: string) =>
    setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.service || !form.date || !form.time) {
      toast.error("Fyll i alla obligatoriska fält.");
      return;
    }
    setSubmitted(true);
    toast.success("Din bokning har skickats! Vi kontaktar dig inom kort.");
  };

  const isStep1Valid = form.name && form.phone && form.email;
  const isStep2Valid = form.carMake && form.carModel && form.service;

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#fafaf8]">
        <Navbar />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center max-w-lg mx-auto px-6"
          >
            <div className="w-20 h-20 bg-green-500 flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={40} className="text-white" />
            </div>
            <h1 className="font-['Oswald'] text-4xl font-bold text-[#0d1b2a] uppercase mb-4">
              Bokning Mottagen!
            </h1>
            <p className="font-['Nunito_Sans'] text-gray-600 text-lg mb-2">
              Tack, <strong>{form.name}</strong>! Din bokningsförfrågan har skickats.
            </p>
            <p className="font-['Nunito_Sans'] text-gray-500 mb-8">
              Vi bekräftar din tid för <strong>{form.service}</strong> den <strong>{form.date}</strong> kl <strong>{form.time}</strong>. Vi kontaktar dig på <strong>{form.phone}</strong> inom kort.
            </p>
            <div className="bg-[#0d1b2a] p-6 text-left mb-8">
              <h3 className="font-['Oswald'] text-white uppercase mb-3">Bokningssammanfattning</h3>
              <div className="space-y-2 font-['Nunito_Sans'] text-white/70 text-sm">
                <div className="flex justify-between"><span>Tjänst:</span><span className="text-white">{form.service}</span></div>
                <div className="flex justify-between"><span>Datum:</span><span className="text-white">{form.date}</span></div>
                <div className="flex justify-between"><span>Tid:</span><span className="text-white">{form.time}</span></div>
                <div className="flex justify-between"><span>Bil:</span><span className="text-white">{form.carMake} {form.carModel} ({form.carYear})</span></div>
                {form.regNumber && <div className="flex justify-between"><span>Reg.nr:</span><span className="text-white">{form.regNumber}</span></div>}
              </div>
            </div>
            <div className="flex gap-4 justify-center">
              <Link href="/">
                <button className="btn-primary">Tillbaka till startsidan</button>
              </Link>
              <a href="tel:018-265-06-08">
                <button className="btn-outline-white bg-[#0d1b2a] border-[#0d1b2a] text-white hover:bg-white hover:text-[#0d1b2a]">
                  Ring oss
                </button>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fafaf8]">
      <Navbar />

      {/* Hero */}
      <div className="bg-[#0d1b2a] pt-16">
        <div className="container py-16">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-white/60 uppercase tracking-[0.2em] text-sm">Bokningsportal</span>
          </div>
          <h1 className="font-['Oswald'] text-4xl md:text-6xl font-bold text-white uppercase mb-4">
            Boka Din Tid
          </h1>
          <p className="font-['Nunito_Sans'] text-white/70 text-lg max-w-xl">
            Boka enkelt online. Vi bekräftar din tid via telefon eller e-post. Du kan också ringa oss direkt på <a href="tel:018-265-06-08" className="text-[#c1121f] font-semibold">018 265 06 08</a>.
          </p>
        </div>
      </div>

      {/* Step indicator */}
      <div className="bg-[#1a2d42] border-b border-white/10">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            {[
              { n: 1, label: "Dina uppgifter", icon: User },
              { n: 2, label: "Din bil & tjänst", icon: Car },
              { n: 3, label: "Datum & tid", icon: Calendar },
            ].map((s, i) => (
              <div key={s.n} className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 flex items-center justify-center font-['Oswald'] font-bold text-sm transition-colors ${
                    step >= s.n ? "bg-[#c1121f] text-white" : "bg-white/10 text-white/40"
                  }`}
                >
                  {step > s.n ? "✓" : s.n}
                </div>
                <span className={`font-['Nunito_Sans'] text-sm hidden sm:block ${step >= s.n ? "text-white" : "text-white/40"}`}>
                  {s.label}
                </span>
                {i < 2 && <div className="w-8 h-px bg-white/20 mx-2 hidden sm:block" />}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit}>
              {/* Step 1: Personal info */}
              {step === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white border border-gray-100 p-8"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <User size={20} className="text-[#c1121f]" />
                    <h2 className="font-['Oswald'] text-2xl font-bold text-[#0d1b2a] uppercase">Dina Uppgifter</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div className="sm:col-span-2">
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        Namn <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => update("name", e.target.value)}
                        placeholder="Förnamn Efternamn"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        Telefon <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => update("phone", e.target.value)}
                        placeholder="070 123 45 67"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        E-post <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => update("email", e.target.value)}
                        placeholder="din@email.se"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                  </div>
                  <div className="mt-6 flex justify-end">
                    <button
                      type="button"
                      onClick={() => isStep1Valid && setStep(2)}
                      disabled={!isStep1Valid}
                      className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Nästa steg →
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Car & service */}
              {step === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white border border-gray-100 p-8"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <Car size={20} className="text-[#c1121f]" />
                    <h2 className="font-['Oswald'] text-2xl font-bold text-[#0d1b2a] uppercase">Din Bil & Tjänst</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        Bilmärke <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="text"
                        value={form.carMake}
                        onChange={(e) => update("carMake", e.target.value)}
                        placeholder="t.ex. Volvo, BMW, Toyota"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        Modell <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="text"
                        value={form.carModel}
                        onChange={(e) => update("carModel", e.target.value)}
                        placeholder="t.ex. V70, 3-serie, Corolla"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">Årsmodell</label>
                      <input
                        type="number"
                        value={form.carYear}
                        onChange={(e) => update("carYear", e.target.value)}
                        placeholder="t.ex. 2018"
                        min="1990"
                        max="2026"
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <VehicleLookup 
                        onCarModelChange={(carModel) => update("carModel", carModel)}
                      />
                    </div>
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">Meddelande <span className="text-[#c1121f]">*</span></label>
                      <textarea
                        value={form.message}
                        onChange={(e) => update("message", e.target.value)}
                        placeholder="Beskriv vad du behöver hjälp med..."
                        rows={4}
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-2">
                        Tjänster <span className="text-[#c1121f]">*</span> (välj en eller flera)
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {SERVICES.map((s) => (
                          <button
                            key={s}
                            type="button"
                            onClick={() => {
                              const services = form.service ? form.service.split(", ") : [];
                              if (services.includes(s)) {
                                update("service", services.filter(srv => srv !== s).join(", "));
                              } else {
                                update("service", [...services, s].join(", "));
                              }
                            }}
                            className={`px-4 py-3 text-left font-['Nunito_Sans'] text-sm border transition-all ${
                              form.service?.includes(s)
                                ? "bg-[#0d1b2a] text-white border-[#0d1b2a]"
                                : "bg-white text-gray-700 border-gray-200 hover:border-[#c1121f]"
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="mt-6 flex justify-between">
                    <button type="button" onClick={() => setStep(1)} className="font-['Nunito_Sans'] text-gray-500 hover:text-[#0d1b2a] text-sm flex items-center gap-1">
                      <ChevronLeft size={16} /> Tillbaka
                    </button>
                    <button
                      type="button"
                      onClick={() => isStep2Valid && setStep(3)}
                      disabled={!isStep2Valid}
                      className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Nästa steg →
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Date & time */}
              {step === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white border border-gray-100 p-8"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <Calendar size={20} className="text-[#c1121f]" />
                    <h2 className="font-['Oswald'] text-2xl font-bold text-[#0d1b2a] uppercase">Välj Datum & Tid</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                    <div>
                      <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                        Datum <span className="text-[#c1121f]">*</span>
                      </label>
                      <input
                        type="date"
                        value={form.date}
                        onChange={(e) => update("date", e.target.value)}
                        min={new Date().toISOString().split("T")[0]}
                        className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-5">
                    <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-2">
                      Tid <span className="text-[#c1121f]">*</span>
                    </label>
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      {TIME_SLOTS.map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => update("time", t)}
                          className={`py-2 font-['Nunito_Sans'] text-sm border transition-all ${
                            form.time === t
                              ? "bg-[#c1121f] text-white border-[#c1121f]"
                              : "bg-white text-gray-700 border-gray-200 hover:border-[#c1121f]"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mb-5">
                    <label className="block font-['Nunito_Sans'] text-sm font-semibold text-gray-700 mb-1">
                      <MessageSquare size={14} className="inline mr-1" />
                      Meddelande (valfritt)
                    </label>
                    <textarea
                      value={form.message}
                      onChange={(e) => update("message", e.target.value)}
                      placeholder="Beskriv problemet eller ange ytterligare information om din bil..."
                      rows={4}
                      className="w-full border border-gray-200 px-4 py-3 font-['Nunito_Sans'] text-sm focus:outline-none focus:border-[#c1121f] transition-colors resize-none"
                    />
                  </div>

                  <div className="flex justify-between">
                    <button type="button" onClick={() => setStep(2)} className="font-['Nunito_Sans'] text-gray-500 hover:text-[#0d1b2a] text-sm flex items-center gap-1">
                      <ChevronLeft size={16} /> Tillbaka
                    </button>
                    <button
                      type="submit"
                      disabled={!form.date || !form.time}
                      className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <CheckCircle size={16} />
                      Skicka Bokning
                    </button>
                  </div>
                </motion.div>
              )}
            </form>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Summary card */}
            <div className="bg-[#0d1b2a] p-6">
              <h3 className="font-['Oswald'] text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                <Wrench size={16} className="text-[#c1121f]" />
                Bokningsöversikt
              </h3>
              <div className="space-y-3 font-['Nunito_Sans'] text-sm">
                {[
                  { label: "Namn", value: form.name || "–" },
                  { label: "Telefon", value: form.phone || "–" },
                  { label: "Bil", value: form.carMake ? `${form.carMake} ${form.carModel}` : "–" },
                  { label: "Tjänst", value: form.service || "–" },
                  { label: "Datum", value: form.date || "–" },
                  { label: "Tid", value: form.time || "–" },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between items-start gap-2">
                    <span className="text-white/40">{item.label}:</span>
                    <span className="text-white text-right">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Contact card */}
            <div className="bg-white border border-gray-100 p-6">
              <h3 className="font-['Oswald'] text-[#0d1b2a] uppercase tracking-wider mb-4">Föredrar du att ringa?</h3>
              <p className="font-['Nunito_Sans'] text-gray-500 text-sm mb-4">
                Vi tar gärna emot din bokning via telefon eller e-post.
              </p>
              <div className="space-y-3">
                <a href="tel:018-265-06-08" className="flex items-center gap-3 text-[#0d1b2a] hover:text-[#c1121f] transition-colors">
                  <Phone size={16} className="text-[#c1121f]" />
                  <span className="font-['Nunito_Sans'] text-sm font-semibold">018 265 06 08</span>
                </a>
                <a href="mailto:Tibblebilverkstad@gmail.com" className="flex items-center gap-3 text-[#0d1b2a] hover:text-[#c1121f] transition-colors">
                  <Mail size={16} className="text-[#c1121f]" />
                  <span className="font-['Nunito_Sans'] text-sm font-semibold">Tibblebilverkstad@gmail.com</span>
                </a>
                <div className="flex items-start gap-3 text-gray-500">
                  <Clock size={16} className="text-[#c1121f] mt-0.5 flex-shrink-0" />
                  <span className="font-['Nunito_Sans'] text-sm">Mån–Fre: 08:00–17:00<br />Lör: 11:00–15:00</span>
                </div>
                <div className="flex items-start gap-3 text-gray-500">
                  <MapPin size={16} className="text-[#c1121f] mt-0.5 flex-shrink-0" />
                  <span className="font-['Nunito_Sans'] text-sm">Bror Hjorths väg 2A, 743 64 Björklinge</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#0a1520] py-8 mt-12">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-['Nunito_Sans'] text-white/30 text-sm">© 2025 Tibbles Bilverkstad AB. Org.nr: 559275-8741</p>
          <Link href="/">
            <a className="font-['Nunito_Sans'] text-white/50 hover:text-white text-sm transition-colors">Tillbaka till startsidan</a>
          </Link>
        </div>
      </footer>
    </div>
  );
}
