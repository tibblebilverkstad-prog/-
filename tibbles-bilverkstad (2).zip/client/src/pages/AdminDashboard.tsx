import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, Loader2 } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

type BookingStatus = "pending" | "confirmed" | "completed" | "cancelled";

const statusColors: Record<BookingStatus, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

const statusLabels: Record<BookingStatus, string> = {
  pending: "Väntande",
  confirmed: "Bekräftad",
  completed: "Slutförd",
  cancelled: "Avbruten",
};

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [expandedBooking, setExpandedBooking] = useState<number | null>(null);

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!authLoading && (!user || user.role !== "admin")) {
      window.location.href = getLoginUrl();
    }
  }, [user, authLoading]);

  const { data: bookings, isLoading, error } = trpc.bookings.list.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const updateStatusMutation = trpc.bookings.updateStatus.useMutation({
    onSuccess: () => {
      // Refetch bookings after status update
      trpc.useUtils().bookings.list.invalidate();
    },
  });

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="animate-spin" size={32} />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bokningshantering</h1>
          <p className="text-gray-600 mt-2">Hantera alla bokningar från dina kunder</p>
        </div>

        {error && (
          <Card className="bg-red-50 border-red-200 p-4">
            <p className="text-red-800">Fel vid hämtning av bokningar: {error.message}</p>
          </Card>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="animate-spin" size={32} />
          </div>
        ) : bookings && bookings.length > 0 ? (
          <div className="space-y-4">
            {bookings.map((booking: any) => (
              <Card key={booking.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg text-gray-900">{booking.customerName}</h3>
                      <Badge className={statusColors[booking.status as BookingStatus]}>
                        {statusLabels[booking.status as BookingStatus]}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <p className="text-gray-400 text-xs uppercase">E-post</p>
                        <p className="font-medium text-gray-900">{booking.customerEmail}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs uppercase">Telefon</p>
                        <p className="font-medium text-gray-900">{booking.customerPhone}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs uppercase">Bil</p>
                        <p className="font-medium text-gray-900">{booking.carModel}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs uppercase">Tid</p>
                        <p className="font-medium text-gray-900">{booking.bookingDate} {booking.bookingTime}</p>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setExpandedBooking(expandedBooking === booking.id ? null : booking.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <ChevronDown
                      size={20}
                      className={`transition-transform ${expandedBooking === booking.id ? "rotate-180" : ""}`}
                    />
                  </button>
                </div>

                {expandedBooking === booking.id && (
                  <div className="mt-6 pt-6 border-t space-y-4">
                    <div>
                      <p className="text-gray-400 text-xs uppercase mb-2">Tjänster</p>
                      <p className="text-gray-900">{booking.services}</p>
                    </div>
                    {booking.message && (
                      <div>
                        <p className="text-gray-400 text-xs uppercase mb-2">Meddelande</p>
                        <p className="text-gray-900">{booking.message}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-gray-400 text-xs uppercase mb-2">Uppdatera status</p>
                      <div className="flex gap-2 flex-wrap">
                        {(["pending", "confirmed", "completed", "cancelled"] as BookingStatus[]).map((status) => (
                          <Button
                            key={status}
                            variant={booking.status === status ? "default" : "outline"}
                            size="sm"
                            onClick={() =>
                              updateStatusMutation.mutate({
                                id: booking.id,
                                status,
                              })
                            }
                            disabled={updateStatusMutation.isPending}
                          >
                            {statusLabels[status]}
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">
                      Skapad: {new Date(booking.createdAt).toLocaleString("sv-SE")}
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-gray-600">Inga bokningar än</p>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
