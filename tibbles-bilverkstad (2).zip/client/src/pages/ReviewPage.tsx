import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Star, Upload, X } from "lucide-react";
import { toast } from "sonner";

export default function ReviewPage() {
  const [formData, setFormData] = useState({
    bookingId: "",
    customerName: "",
    customerEmail: "",
    rating: 5,
    comment: "",
    services: "",
    carModel: "",
    imageUrl: "",
  });

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  const uploadImage = trpc.reviews.uploadImage.useMutation();
  const createReview = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success("Tack för din recension! Den granskas innan den publiceras.");
      setFormData({
        bookingId: "",
        customerName: "",
        customerEmail: "",
        rating: 5,
        comment: "",
        services: "",
        carModel: "",
        imageUrl: "",
      });
      setImagePreview(null);
    },
    onError: (error) => {
      toast.error("Något gick fel: " + error.message);
    },
  });

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Bilden är för stor. Max 5MB.");
      return;
    }

    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Vänligen välj en bildfil (JPG, PNG, etc.)");
      return;
    }

    setIsUploadingImage(true);

    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        const base64Data = base64.split(",")[1]; // Remove data:image/... prefix

        // Upload to S3
        const result = await uploadImage.mutateAsync({
          fileName: file.name,
          fileData: base64Data,
          mimeType: file.type,
        });

        setFormData({ ...formData, imageUrl: result.url });
        setImagePreview(result.url);
        toast.success("Bild uppladdad!");
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast.error("Kunde inte ladda upp bild. Försök igen senare.");
    } finally {
      setIsUploadingImage(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.customerName || !formData.customerEmail || !formData.services || !formData.carModel) {
      toast.error("Vänligen fyll i alla obligatoriska fält");
      return;
    }

    createReview.mutate({
      bookingId: parseInt(formData.bookingId) || 0,
      customerName: formData.customerName,
      customerEmail: formData.customerEmail,
      rating: formData.rating,
      comment: formData.comment,
      services: formData.services,
      carModel: formData.carModel,
      imageUrl: formData.imageUrl || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-[#fafaf8] py-12">
      <div className="container max-w-2xl">
        <div className="mb-8">
          <h1 className="font-['Oswald'] text-4xl font-bold text-[#0d1b2a] uppercase mb-4">
            Lämna en Recension
          </h1>
          <p className="font-['Nunito_Sans'] text-gray-600">
            Vi värdesätter din feedback! Berätta om din erfarenhet av vår service och ladda upp bilder av din bil.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white p-8 shadow-lg">
          {/* Customer Name */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Ditt Namn *
            </label>
            <input
              type="text"
              required
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
              placeholder="Ditt namn"
            />
          </div>

          {/* Customer Email */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              E-postadress *
            </label>
            <input
              type="email"
              required
              value={formData.customerEmail}
              onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
              placeholder="din@email.com"
            />
          </div>

          {/* Car Model */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Bilmodell *
            </label>
            <input
              type="text"
              required
              value={formData.carModel}
              onChange={(e) => setFormData({ ...formData, carModel: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
              placeholder="t.ex. BMW X5, Volvo V90"
            />
          </div>

          {/* Services */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Tjänster *
            </label>
            <input
              type="text"
              required
              value={formData.services}
              onChange={(e) => setFormData({ ...formData, services: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
              placeholder="t.ex. Service, Däckbyte"
            />
          </div>

          {/* Rating */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-4">
              Betyg *
            </label>
            <div className="flex gap-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setFormData({ ...formData, rating: star })}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    size={32}
                    className={
                      star <= formData.rating
                        ? "fill-amber-400 text-amber-400"
                        : "text-gray-300"
                    }
                  />
                </button>
              ))}
            </div>
            <p className="font-['Nunito_Sans'] text-gray-600 text-sm mt-2">
              {formData.rating} av 5 stjärnor
            </p>
          </div>

          {/* Comment */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Kommentar
            </label>
            <textarea
              value={formData.comment}
              onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f] h-32 resize-none"
              placeholder="Berätta om din erfarenhet..."
            />
          </div>

          {/* Image Upload */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Ladda upp Bild av Din Bil (valfritt)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-[#c1121f] transition-colors">
              {imagePreview ? (
                <div className="relative">
                  <img src={imagePreview} alt="Preview" className="w-full h-48 object-cover rounded mb-4" />
                  <button
                    type="button"
                    onClick={() => {
                      setImagePreview(null);
                      setFormData({ ...formData, imageUrl: "" });
                    }}
                    className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full hover:bg-red-600"
                  >
                    <X size={16} />
                  </button>
                </div>
              ) : (
                <div>
                  <Upload size={32} className="mx-auto text-gray-400 mb-2" />
                  <p className="font-['Nunito_Sans'] text-gray-600 mb-2">
                    Dra och släpp en bild här eller klicka för att välja
                  </p>
                  <p className="font-['Nunito_Sans'] text-gray-500 text-sm">
                    Max 5MB. JPG, PNG eller annat bildformat.
                  </p>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                disabled={isUploadingImage}
                className="hidden"
                id="image-input"
              />
              <label
                htmlFor="image-input"
                className="inline-block mt-4 px-6 py-2 bg-[#0d1b2a] text-white font-['Oswald'] uppercase cursor-pointer hover:bg-[#c1121f] transition-colors"
              >
                {isUploadingImage ? "Laddar upp..." : "Välj Bild"}
              </label>
            </div>
          </div>

          {/* Booking ID (optional) */}
          <div className="mb-6">
            <label className="block font-['Oswald'] text-[#0d1b2a] uppercase mb-2">
              Boknings-ID (valfritt)
            </label>
            <input
              type="number"
              value={formData.bookingId}
              onChange={(e) => setFormData({ ...formData, bookingId: e.target.value })}
              className="w-full border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
              placeholder="Ditt boknings-ID"
            />
            <p className="font-['Nunito_Sans'] text-gray-500 text-sm mt-1">
              Om du har ett boknings-ID från oss, ange det här
            </p>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={createReview.isPending}
            className="w-full bg-[#c1121f] hover:bg-[#a00d1a] text-white font-['Oswald'] uppercase py-3"
          >
            {createReview.isPending ? "Skickar..." : "Skicka Recension"}
          </Button>

          <p className="font-['Nunito_Sans'] text-gray-500 text-sm mt-4 text-center">
            Din recension granskas innan den publiceras på vår webbplats.
          </p>
        </form>
      </div>
    </div>
  );
}
