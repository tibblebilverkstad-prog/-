/*
 * HOME PAGE – Tibbles Bilverkstad
 * Design: Nordisk hantverk möter modern precision
 * Navy #0d1b2a | Red #c1121f | Oswald headings | Nunito Sans body
 */

import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import {
  Wrench, Car, Shield, Clock, Phone, Mail, MapPin,
  Star, ChevronLeft, ChevronRight, Menu, X, Calendar,
  Zap, Droplets, Settings, AlertTriangle, Wind, Eye, ChevronDown
} from "lucide-react";

// ─── Image CDN URLs ───────────────────────────────────────────────────────────
const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/logo_8039c376.jpg";
const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/hero_workshop-W3FUWRbfAPsapWEmCeg5S7.webp";
const MECHANIC_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/service_mechanic-6yAJAi5YSZvDkWFHDjzZQb.webp";
const EXTERIOR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/workshop_exterior-mH62wJDirHtM4dFELckxdx.webp";

const BMW_EXTERIOR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_exterior_a7425944.jpeg";
const BMW_ENGINE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_engine_6335278d.jpeg";
const BMW_INTERIOR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_interior_dad2f482.jpeg";
const BMW_SEATS = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_seats_c97aa460.jpeg";
const BMW_FRONT = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_front_7a187eb0.jpeg";
const RANGE_ROVER = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/range_rover_service_a512edec.jpeg";
const BMW_WHEEL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663457150282/UFzcGc5SneSo2hUoUu4ayF/bmw_x7_wheel_38599ebb.jpeg";

// ─── Data ─────────────────────────────────────────────────────────────────────
const SERVICES = [
  { icon: Settings, title: "Service & Underhåll", desc: "Motorolja, filter, bromsbelägg, bromsskivor och all löpande service för att hålla din bil i toppskick." },
  { icon: Zap, title: "Elproblem & Diagnostik", desc: "Modern diagnostikutrustning för att snabbt hitta och åtgärda elektriska fel i alla bilmärken." },
  { icon: Shield, title: "Bromsar & Säkerhet", desc: "Byte av bromsbelägg, bromsskivor och bromsvätska. Din säkerhet är vår prioritet." },
  { icon: Droplets, title: "Rekond & Biltvätt", desc: "Professionell rekonditionering – invändig och utvändig rengöring, polering och lackskydd." },
  { icon: Wind, title: "Däck & Fälgar", desc: "Däckbyte, balansering och förvaring. Vi hjälper dig med rätt däck för alla årstider." },
  { icon: Eye, title: "Glasskador", desc: "Byte och reparation av vindrutor och bakrutor. Snabb och professionell service." },
  { icon: AlertTriangle, title: "Försäkringsärenden", desc: "Vi hjälper dig med hela försäkringsprocessen vid skador – smidigt och stressfritt." },
  { icon: Wrench, title: "Motorbyte & Renovering", desc: "Från mindre reparationer till fullständiga motorbyten. Erfarenhet av alla märken och modeller." },
];

const REVIEWS = [
  { name: "Kristin Österberg", rating: 5, time: "3 månader sedan", text: "Kl 16.56 kliver jag in i vinst och förlust. (Stänger 17) Hjälpen och lösningen tog 45 minuter och servicen var inget annat än trevlig, lösningsfokuserad och ytterligare en nöjd kund lämnar med en fungerande bil. Stort tack, killar!" },
  { name: "Zina Währb", rating: 5, time: "2 månader sedan", text: "Otroligt serviceinriktad och kunnig personal som löste problemet sent dagen före julafton och därmed också julen för oss. 10/10 stjärnor rekommenderas varmt. Tack för hjälpen!" },
  { name: "Kristofer", rating: 5, time: "4 månader sedan", text: "Bytte styrleder, kamrem, flerbälte och vattenpump på Volvon, allt klart samma dag som jag lämnade in den. Guldstjärna till gänget som kör och tack för den fantastiska servicen!" },
  { name: "Niclas Ottersgård", rating: 5, time: "5 månader sedan", text: "Fick punktering. De kunde ta emot mig samma dag en timme senare. Enastående service och väldigt trevliga. Ett självklart val framöver!" },
  { name: "Joakim Vingren", rating: 5, time: "4 månader sedan", text: "Bad om tid för att byta däck 50 minuter före stängning. 'Du kan komma in direkt'. Väldigt bra service!" },
  { name: "Magnus Holmstam", rating: 5, time: "5 månader sedan", text: "Det var dags för oljebyte och jag fick tid dagen efter att jag ringde. Snabbt, enkelt och till ett bra pris." },
  { name: "Christina Fällgren", rating: 5, time: "1 månad sedan", text: "Väldigt trevlig service. Fick tid snabbt för att fixa mitt halvljus som slutat fungera. Tack och på återseende!" },
  { name: "Gunilla Jakobsson", rating: 5, time: "4 månader sedan", text: "Snabb och bra hjälp som vanligt. Nu fungerar halvljuset som det ska." },
  { name: "Kim Nevelsteen", rating: 5, time: "11 månader sedan", text: "Rakt på sak och snabbt. Professionell service utan krångel – precis vad man vill ha av en bilverkstad." },
  { name: "Claes Enwall", rating: 5, time: "1 år sedan", text: "Rullade in med ett fel i bilens elsystem kl 16 en fredag. Trots att det var sent fick jag snabb och professionell hjälp. Imponerande service!" },
];

const GALLERY_ITEMS = [
  { src: BMW_EXTERIOR, caption: "BMW X7 M50i – Rekond, exteriör", tag: "Rekond" },
  { src: BMW_ENGINE, caption: "BMW X7 – Motorrum efter rengöring", tag: "Rekond" },
  { src: BMW_INTERIOR, caption: "BMW X7 – Interiör efter rekond", tag: "Rekond" },
  { src: BMW_SEATS, caption: "BMW X7 – Säten och golv rengjorda", tag: "Rekond" },
  { src: BMW_FRONT, caption: "BMW X7 – Motorhuv öppen, service", tag: "Service" },
  { src: RANGE_ROVER, caption: "Range Rover – Stor service", tag: "Service" },
  { src: BMW_WHEEL, caption: "BMW X7 – Hjul och fälgar efter rekond", tag: "Rekond" },
];

const FAQ = [
  {
    question: "Hur lång tid tar en vanlig service?",
    answer: "En vanlig service tar vanligtvis 1–2 timmar beroende på bilens ålder och skick. Vi strävar alltid efter att lämna tillbaka din bil samma dag. Kontakta oss för en tidsuppskattning."
  },
  {
    question: "Vilka märken arbetar ni med?",
    answer: "Vi arbetar med alla bilmärken och modeller – Volvo, BMW, Mercedes, Audi, Toyota, Volkswagen, Fiat, Renault och många fler. Oavsett märke eller ålder kan vi hjälpa dig."
  },
  {
    question: "Hur mycket kostar en oljebyte?",
    answer: "Priset på oljebyte varierar beroende på bilmodell och oljetyp. Ring oss på 018 265 06 08 för ett exakt pris."
  },
  {
    question: "Kan jag boka tid online?",
    answer: "Ja! Du kan boka tid direkt på vår webbplats via bokningsportalen. Du kan också ringa oss på 018 265 06 08 eller e-posta Tibblebilverkstad@gmail.com."
  },
  {
    question: "Vad gör ni vid försäkringsärenden?",
    answer: "Vi hjälper dig med hela processen vid försäkringsärenden – från skadeanmälan till reparation. Vi kommunicerar direkt med försäkringsbolaget för att göra det enkelt för dig."
  },
  {
    question: "Hur ofta bör jag byta däck?",
    answer: "Vinterdäck ska användas från 1 december till 31 mars. Byt däck när mönsterdjupet är under 3 mm för vinterdäck och 1,6 mm för sommardäck. Vi kan inspektera dina däck gratis."
  },
  {
    question: "Erbjuder ni däckförvaring?",
    answer: "Ja, vi erbjuder säker däckförvaring till ett lågt pris. Vi tar hand om dina däck mellan säsongerna så du slipper lagra dem hemma."
  },
  {
    question: "Vad är en rekond?",
    answer: "Rekond är en grundlig rengöring och vård av bilen – både invändig och utvändig. Vi rengör motorn, interiören, polerar lacken och applicerar lackskydd för att bilen ska se ut som ny."
  },
  {
    question: "Hur snabbt kan ni fixa en punktering?",
    answer: "Punkteringar är ofta vårt snabbaste jobb! Vi kan vanligtvis reparera eller byta ett däck på under 30 minuter. Kom in utan tid eller ring oss."
  },
  {
    question: "Vilka betalningsmetoder accepterar ni?",
    answer: "Vi accepterar kort och Swish. Kontakta oss för fakturering vid större arbeten."
  },
];

const CAR_INFO = [
  {
    title: "Regelbunden Service Sparar Pengar",
    content: "Att hålla bilen välservad är den bästa investeringen du kan göra. Regelbundna oljebyten, filterbyten och kontroll av bromsar förebygger kostsamma reparationer. Vi rekommenderar service var 15 000–20 000 km eller en gång per år.",
    icon: "🔧"
  },
  {
    title: "Däckens Betydelse för Säkerheten",
    content: "Rätt däck räddar liv. Vinterdäck ska sitta på från 1 december till 31 mars (eller vid vinterväglag). Kontrollera mönsterdjupet regelbundet – minimum 3 mm för vinterdäck och 1,6 mm för sommardäck rekommenderas.",
    icon: "🏎️"
  },
  {
    title: "Bromsarna – Livsviktig Säkerhet",
    content: "Bromsar slits gradvis och det kan vara svårt att märka försämringen. Tecken på att det är dags: skrapande ljud, vibrationer i ratten, längre bromssträcka eller att bilen drar åt sidan. Låt oss kontrollera dina bromsar!",
    icon: "🛑"
  },
  {
    title: "Elektriska System i Moderna Bilar",
    content: "Moderna bilar har komplexa elektriska system. Varningslampor ska aldrig ignoreras. Med vår moderna diagnostikutrustning kan vi snabbt läsa av felkoder och identifiera problemet – oavsett bilmärke.",
    icon: "⚡"
  },
];

// ─── Star Rating Component ────────────────────────────────────────────────────
function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          size={16}
          className={s <= rating ? "fill-amber-400 text-amber-400" : "text-gray-300"}
        />
      ))}
    </div>
  );
}

// ─── Animated Counter ─────────────────────────────────────────────────────────
function AnimatedNumber({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const duration = 1500;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) { setCount(target); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target]);

  return <span ref={ref}>{count}{suffix}</span>;
}

// ─── Navigation ───────────────────────────────────────────────────────────────
function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { href: "#tjanster", label: "Tjänster" },
    { href: "#om-oss", label: "Om Oss" },
    { href: "#galleri", label: "Galleri" },
    { href: "#recensioner", label: "Recensioner" },
    { href: "#bilinformation", label: "Bilinformation" },
    { href: "#kontakt", label: "Kontakt" },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#0d1b2a] shadow-2xl" : "bg-[#0d1b2a]/90 backdrop-blur-sm"
      }`}
    >
      <div className="container flex items-center justify-between h-16">
        <a href="#" className="flex items-center gap-2">
          <img src={LOGO_URL} alt="Tibbles Bilverkstad Logo" className="h-16 w-auto" />
        </a>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-6">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="font-['Nunito_Sans'] text-sm text-white/80 hover:text-white transition-colors uppercase tracking-wider"
            >
              {l.label}
            </a>
          ))}
          <Link href="/boka">
            <button className="btn-primary text-sm px-5 py-2">Boka Tid</button>
          </Link>
        </div>

        {/* Mobile menu button */}
        <button
          className="lg:hidden text-white p-2"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden bg-[#0d1b2a] border-t border-white/10 py-4">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block px-6 py-3 text-white/80 hover:text-white hover:bg-white/5 font-['Nunito_Sans'] uppercase tracking-wider text-sm"
            >
              {l.label}
            </a>
          ))}
          <div className="px-6 pt-3">
            <Link href="/boka">
              <button className="btn-primary w-full text-sm" onClick={() => setOpen(false)}>Boka Tid</button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}

// ─── Hero Section ─────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img src={HERO_IMG} alt="Tibbles Bilverkstad" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d1b2a]/95 via-[#0d1b2a]/75 to-[#0d1b2a]/30" />
      </div>

      {/* Diagonal accent */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 bg-[#fafaf8]"
        style={{ clipPath: "polygon(0 100%, 100% 0, 100% 100%)" }}
      />

      <div className="container relative z-10 pt-16">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="h-1 w-12 bg-[#c1121f]" />
              <span className="font-['Nunito_Sans'] text-white/70 uppercase tracking-[0.2em] text-sm">
                Björklinge, Uppsala
              </span>
            </div>
            <h1 className="font-['Oswald'] text-5xl md:text-7xl font-bold text-white uppercase leading-none mb-4">
              Din Trygga<br />
              <span className="text-[#c1121f]">Bilverkstad</span>
            </h1>
            <p className="font-['Nunito_Sans'] text-white/80 text-lg md:text-xl mb-8 leading-relaxed max-w-xl">
              Professionell bilservice i Björklinge sedan starten. Vi arbetar med alla märken och modeller – från service och bromsar till rekond och glasskador.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/boka">
                <button className="btn-primary flex items-center gap-2">
                  <Calendar size={18} />
                  Boka Tid Online
                </button>
              </Link>
              <a href="tel:018-265-06-08">
                <button className="btn-outline-white flex items-center gap-2">
                  <Phone size={18} />
                  018 265 06 08
                </button>
              </a>
            </div>

            {/* Quick stats */}
            <div className="flex gap-8 mt-12">
              <div>
                <div className="font-['Oswald'] text-3xl font-bold text-white">
                  <AnimatedNumber target={57} />+
                </div>
                <div className="font-['Nunito_Sans'] text-white/60 text-sm uppercase tracking-wider">Google-recensioner</div>
              </div>
              <div className="w-px bg-white/20" />
              <div>
                <div className="font-['Oswald'] text-3xl font-bold text-[#c1121f]">4.3</div>
                <div className="font-['Nunito_Sans'] text-white/60 text-sm uppercase tracking-wider">Betyg på Google</div>
              </div>
              <div className="w-px bg-white/20" />
              <div>
                <div className="font-['Oswald'] text-3xl font-bold text-white">
                  <AnimatedNumber target={100} />%
                </div>
                <div className="font-['Nunito_Sans'] text-white/60 text-sm uppercase tracking-wider">Nöjda kunder</div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ─── Services Section ─────────────────────────────────────────────────────────
function Services() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="tjanster" className="py-24 bg-[#fafaf8]" ref={ref}>
      <div className="container">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-[#c1121f] uppercase tracking-[0.2em] text-sm font-semibold">Vad vi erbjuder</span>
          </div>
          <h2 className="section-title text-4xl md:text-5xl text-[#0d1b2a] red-underline mb-6">
            Våra Tjänster
          </h2>
          <p className="font-['Nunito_Sans'] text-gray-600 text-lg max-w-2xl">
            Vi erbjuder ett komplett utbud av bilservice och reparationer. Oavsett märke eller modell – vi tar hand om din bil med hög kvalitet och snabb service.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: i * 0.07 }}
              className="group bg-white border border-gray-100 p-6 hover:border-[#c1121f] hover:shadow-xl transition-all duration-300 cursor-default"
            >
              <div className="w-12 h-12 bg-[#0d1b2a] flex items-center justify-center mb-4 group-hover:bg-[#c1121f] transition-colors duration-300">
                <s.icon size={22} className="text-white" />
              </div>
              <h3 className="font-['Oswald'] text-lg font-semibold text-[#0d1b2a] uppercase mb-2">{s.title}</h3>
              <p className="font-['Nunito_Sans'] text-gray-500 text-sm leading-relaxed">{s.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link href="/boka">
            <button className="btn-primary">Boka Din Service Nu</button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// ─── About Section ────────────────────────────────────────────────────────────
function About() {
  return (
    <section id="om-oss" className="py-24 bg-[#0d1b2a]">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-1 w-8 bg-[#c1121f]" />
              <span className="font-['Nunito_Sans'] text-white/60 uppercase tracking-[0.2em] text-sm">Om oss</span>
            </div>
            <h2 className="section-title text-4xl md:text-5xl text-white mb-6">
              Tibbles Bilverkstad<br />
              <span className="text-[#c1121f]">– Bilxtra Björklinge</span>
            </h2>
            <p className="font-['Nunito_Sans'] text-white/70 text-lg leading-relaxed mb-6">
              Tibbles Bilverkstad i Björklinge är ditt trygga val när du behöver professionell bilservice och reparationer. Vi arbetar med allt från service och bromsar till motorbyte, elproblem, glasskador och försäkringsärenden.
            </p>
            <p className="font-['Nunito_Sans'] text-white/70 leading-relaxed mb-8">
              Med hög kvalitet och snabb service strävar vi alltid efter att lämna tillbaka din bil samma dag. Tack vare vår samarbetspartner Bilxtra kan vi erbjuda snabba leveranser av reservdelar och expressservice som gör livet enklare för våra kunder.
            </p>

            <div className="grid grid-cols-2 gap-6 mb-8">
              {[
                { icon: Clock, label: "Öppettider", value: "Mån–Fre 08–17, Lör 11–15" },
                { icon: Phone, label: "Telefon", value: "018 265 06 08" },
                { icon: Mail, label: "E-post", value: "Tibblebilverkstad@gmail.com" },
                { icon: MapPin, label: "Adress", value: "Bror Hjorths väg 2A, Björklinge" },
              ].map((item) => (
                <div key={item.label} className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-[#c1121f]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <item.icon size={18} className="text-[#c1121f]" />
                  </div>
                  <div>
                    <div className="font-['Nunito_Sans'] text-white/40 text-xs uppercase tracking-wider">{item.label}</div>
                    <div className="font-['Nunito_Sans'] text-white text-sm font-semibold">{item.value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4">
              <Link href="/boka">
                <button className="btn-primary">Boka Tid</button>
              </Link>
              <a href="https://maps.google.com/?q=Tibbles+Bilverkstad+Björklinge" target="_blank" rel="noopener noreferrer">
                <button className="btn-outline-white">Hitta Hit</button>
              </a>
            </div>
          </div>

          <div className="relative">
            <img
              src={EXTERIOR_IMG}
              alt="Tibbles Bilverkstad exteriör"
              className="w-full h-80 lg:h-[500px] object-cover"
            />
            <div className="absolute -bottom-6 -left-6 bg-[#c1121f] p-6 hidden lg:block">
              <div className="font-['Oswald'] text-4xl font-bold text-white">4.3</div>
              <div className="font-['Nunito_Sans'] text-white/80 text-sm">Google Betyg</div>
              <div className="flex gap-0.5 mt-1">
                {[1,2,3,4,5].map(s => (
                  <Star key={s} size={14} className={s <= 4 ? "fill-white text-white" : "text-white/50"} />
                ))}
              </div>
              <div className="font-['Nunito_Sans'] text-white/70 text-xs mt-1">57 recensioner</div>
            </div>
            <div className="absolute -top-6 -right-6 bg-[#0d1b2a] border border-white/20 p-4 hidden lg:block">
              <img src={MECHANIC_IMG} alt="Mekaniker" className="w-32 h-32 object-cover" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Gallery Section ──────────────────────────────────────────────────────────
function Gallery() {
  const [selected, setSelected] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>("Alla");
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  const categories = ["Alla", "Rekond", "Service", "Reparation", "Däck"];
  const filteredItems = activeFilter === "Alla" 
    ? GALLERY_ITEMS 
    : GALLERY_ITEMS.filter(item => item.tag === activeFilter);

  return (
    <section id="galleri" className="py-24 bg-[#fafaf8]">
      <div className="container">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-[#c1121f] uppercase tracking-[0.2em] text-sm font-semibold">Vårt arbete</span>
          </div>
          <h2 className="section-title text-4xl md:text-5xl text-[#0d1b2a] red-underline mb-4">
            Resultat & Galleri
          </h2>
          <p className="font-['Nunito_Sans'] text-gray-600 text-lg max-w-2xl">
            Se resultaten av vårt arbete. Från professionell rekond till stora serviceuppdrag – vi är stolta över varje bil vi tar hand om.
          </p>
        </div>

        {/* Category Filter */}
        <div className="mb-8 flex flex-wrap gap-3">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-6 py-2 font-['Oswald'] text-sm uppercase tracking-wider transition-all ${
                activeFilter === cat
                  ? "bg-[#0d1b2a] text-white border border-[#0d1b2a]"
                  : "bg-white text-[#0d1b2a] border border-gray-300 hover:border-[#c1121f]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry-style grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3" ref={ref}>
          {filteredItems.map((item, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
              className={`relative overflow-hidden cursor-pointer group ${
                i === 0 ? "col-span-2 row-span-2" : ""
              }`}
              onClick={() => setSelected(i)}
            >
              <img
                src={item.src}
                alt={item.caption}
                className="w-full h-full object-cover"
                style={{ minHeight: i === 0 ? "320px" : "180px", maxHeight: i === 0 ? "400px" : "220px" }}
              />
              <div className="absolute inset-0 bg-[#0d1b2a]/0 group-hover:bg-[#0d1b2a]/60 transition-all duration-300 flex items-end p-4">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="inline-block bg-[#c1121f] text-white text-xs font-['Oswald'] uppercase tracking-wider px-2 py-1 mb-1">
                    {item.tag}
                  </span>
                  <p className="font-['Nunito_Sans'] text-white text-sm">{item.caption}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Lightbox */}
        {selected !== null && (
          <div
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setSelected(null)}
          >
            <div className="relative max-w-4xl w-full" onClick={(e) => e.stopPropagation()}>
              <img
                src={filteredItems[selected].src}
                alt={filteredItems[selected].caption}
                className="w-full max-h-[80vh] object-contain"
              />
              <p className="font-['Nunito_Sans'] text-white text-center mt-3 text-sm">
                {filteredItems[selected].caption}
              </p>
              <button
                className="absolute top-2 right-2 bg-[#c1121f] text-white w-10 h-10 flex items-center justify-center"
                onClick={() => setSelected(null)}
              >
                <X size={20} />
              </button>
              <button
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white w-10 h-10 flex items-center justify-center"
                onClick={() => setSelected((selected - 1 + filteredItems.length) % filteredItems.length)}
              >
                <ChevronLeft size={20} />
              </button>
              <button
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/20 hover:bg-white/40 text-white w-10 h-10 flex items-center justify-center"
                onClick={() => setSelected((selected + 1) % filteredItems.length)}
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

// ─── Reviews Section ──────────────────────────────────────────────────────────
function Reviews() {
  const [current, setCurrent] = useState(0);
  const visibleCount = 3;
  const maxIndex = REVIEWS.length - visibleCount;

  const prev = () => setCurrent((c) => Math.max(0, c - 1));
  const next = () => setCurrent((c) => Math.min(maxIndex, c + 1));

  return (
    <section id="recensioner" className="py-24 bg-[#0d1b2a]">
      <div className="container">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-14 gap-6">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-1 w-8 bg-[#c1121f]" />
              <span className="font-['Nunito_Sans'] text-white/60 uppercase tracking-[0.2em] text-sm">Vad kunderna säger</span>
            </div>
            <h2 className="section-title text-4xl md:text-5xl text-white">
              Google<br />
              <span className="text-[#c1121f]">Recensioner</span>
            </h2>
          </div>
          <div className="flex flex-col items-start md:items-end gap-2">
            <div className="flex items-center gap-3">
              <div className="font-['Oswald'] text-5xl font-bold text-white">4.3</div>
              <div>
                <div className="flex gap-1">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} size={20} className={s <= 4 ? "fill-amber-400 text-amber-400" : "text-amber-400/40"} />
                  ))}
                </div>
                <div className="font-['Nunito_Sans'] text-white/60 text-sm">57 recensioner på Google</div>
              </div>
            </div>
            <a
              href="https://maps.google.com/?q=Tibbles+Bilverkstad+Björklinge"
              target="_blank"
              rel="noopener noreferrer"
              className="font-['Nunito_Sans'] text-[#c1121f] text-sm hover:text-white transition-colors underline"
            >
              Se alla recensioner på Google Maps →
            </a>
          </div>
        </div>

        {/* Reviews carousel */}
        <div className="overflow-hidden">
          <motion.div
            className="flex gap-6"
            animate={{ x: `calc(-${current * (100 / visibleCount)}% - ${current * 24 / visibleCount}px)` }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            {REVIEWS.map((r, i) => (
              <div
                key={i}
                className="flex-shrink-0 bg-[#1a2d42] border border-white/10 p-6 hover:border-[#c1121f]/50 transition-colors"
                style={{ width: `calc(${100 / visibleCount}% - ${(visibleCount - 1) * 24 / visibleCount}px)`, minWidth: "280px" }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="font-['Oswald'] text-white font-semibold text-lg">{r.name}</div>
                    <div className="font-['Nunito_Sans'] text-white/40 text-xs">{r.time}</div>
                  </div>
                  <div className="flex items-center gap-1 bg-white/5 px-2 py-1">
                    <Star size={12} className="fill-amber-400 text-amber-400" />
                    <span className="font-['Oswald'] text-white text-sm">{r.rating}</span>
                  </div>
                </div>
                <StarRating rating={r.rating} />
                <p className="font-['Nunito_Sans'] text-white/70 text-sm leading-relaxed mt-4 line-clamp-4">
                  "{r.text}"
                </p>
                <div className="mt-4 flex items-center gap-2">
                  <div className="w-5 h-5 flex-shrink-0">
                    <svg viewBox="0 0 24 24" className="w-full h-full">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                  </div>
                  <span className="font-['Nunito_Sans'] text-white/40 text-xs">Google Recension</span>
                </div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          <div className="font-['Nunito_Sans'] text-white/40 text-sm">
            {current + 1}–{Math.min(current + visibleCount, REVIEWS.length)} av {REVIEWS.length}
          </div>
          <div className="flex gap-3">
            <button
              onClick={prev}
              disabled={current === 0}
              className="w-10 h-10 border border-white/20 flex items-center justify-center text-white disabled:opacity-30 hover:border-[#c1121f] hover:bg-[#c1121f] transition-all"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={next}
              disabled={current >= maxIndex}
              className="w-10 h-10 border border-white/20 flex items-center justify-center text-white disabled:opacity-30 hover:border-[#c1121f] hover:bg-[#c1121f] transition-all"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Car Information Section ──────────────────────────────────────────────────
function CarInformation() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="bilinformation" className="py-24 bg-[#fafaf8]" ref={ref}>
      <div className="container">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-[#c1121f] uppercase tracking-[0.2em] text-sm font-semibold">Kunskap</span>
          </div>
          <h2 className="section-title text-4xl md:text-5xl text-[#0d1b2a] red-underline mb-4">
            Bilinformation
          </h2>
          <p className="font-['Nunito_Sans'] text-gray-600 text-lg max-w-2xl">
            Lär dig mer om din bil och hur du håller den i toppskick. Vår erfarenhet delar vi gärna med oss av.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {CAR_INFO.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex gap-6 bg-white border border-gray-100 p-8 hover:shadow-lg transition-shadow"
            >
              <div className="text-4xl flex-shrink-0">{item.icon}</div>
              <div>
                <h3 className="font-['Oswald'] text-xl font-semibold text-[#0d1b2a] uppercase mb-3">{item.title}</h3>
                <p className="font-['Nunito_Sans'] text-gray-600 leading-relaxed">{item.content}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 bg-[#0d1b2a] p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-['Oswald'] text-2xl md:text-3xl font-bold text-white uppercase mb-2">
              Osäker på din bil?
            </h3>
            <p className="font-['Nunito_Sans'] text-white/70">
              Ring oss eller boka en tid – vi hjälper dig att förstå vad din bil behöver.
            </p>
          </div>
          <div className="flex gap-4 flex-shrink-0">
            <a href="tel:018-265-06-08">
              <button className="btn-primary flex items-center gap-2">
                <Phone size={16} />
                Ring Oss
              </button>
            </a>
            <Link href="/boka">
              <button className="btn-outline-white">Boka Tid</button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FAQ Section ───────────────────────────────────────────────────────────
function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="faq" className="py-24 bg-[#fafaf8]" ref={ref}>
      <div className="container">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-[#c1121f] uppercase tracking-[0.2em] text-sm font-semibold">Frågor & Svar</span>
          </div>
          <h2 className="section-title text-4xl md:text-5xl text-[#0d1b2a] red-underline mb-4">
            Vanliga Frågor
          </h2>
          <p className="font-['Nunito_Sans'] text-gray-600 text-lg max-w-2xl">
            Här svarar vi på de frågor vi ofta får från våra kunder. Kan du inte hitta svar på din fråga? Kontakta oss gärna!
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-3">
          {FAQ.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="bg-white border border-gray-100 hover:border-[#c1121f] transition-all"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors"
              >
                <h3 className="font-['Oswald'] text-lg font-semibold text-[#0d1b2a] uppercase">
                  {item.question}
                </h3>
                <ChevronDown
                  size={20}
                  className={`text-[#c1121f] flex-shrink-0 transition-transform duration-300 ${
                    openIndex === i ? "rotate-180" : ""
                  }`}
                />
              </button>
              {openIndex === i && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="border-t border-gray-100 px-6 py-4 bg-gray-50"
                >
                  <p className="font-['Nunito_Sans'] text-gray-600 leading-relaxed">
                    {item.answer}
                  </p>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="font-['Nunito_Sans'] text-gray-600 mb-4">
            Kan du inte hitta svar på din fråga?
          </p>
          <div className="flex gap-4 justify-center">
            <a href="tel:018-265-06-08">
              <button className="btn-primary flex items-center gap-2">
                <Phone size={16} />
                Ring Oss
              </button>
            </a>
            <a href="mailto:Tibblebilverkstad@gmail.com">
              <button className="btn-outline-white bg-[#0d1b2a] border-[#0d1b2a] text-white hover:bg-white hover:text-[#0d1b2a]">
                E-posta Oss
              </button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Contact / Map Section ───────────────────────────────────────────────────────────
function Contact() {
  return (
    <section id="kontakt" className="py-24 bg-white">
      <div className="container">
        <div className="mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-1 w-8 bg-[#c1121f]" />
            <span className="font-['Nunito_Sans'] text-[#c1121f] uppercase tracking-[0.2em] text-sm font-semibold">Hitta oss</span>
          </div>
          <h2 className="section-title text-4xl md:text-5xl text-[#0d1b2a] red-underline mb-4">
            Kontakt & Hitta Hit
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact info */}
          <div className="space-y-6">
            {[
              { icon: MapPin, label: "Adress", value: "Bror Hjorths väg 2A\n743 64 Björklinge, Sverige", href: "https://maps.google.com/?q=Tibbles+Bilverkstad+Björklinge" },
              { icon: Phone, label: "Telefon", value: "018 265 06 08", href: "tel:018-265-06-08" },
              { icon: Mail, label: "E-post", value: "Tibblebilverkstad@gmail.com", href: "mailto:Tibblebilverkstad@gmail.com" },
              { icon: Clock, label: "Öppettider", value: "Måndag–Fredag: 08:00–17:00\nLördag: 11:00–15:00\nSöndag: Stängt", href: null },
            ].map((item) => (
              <div key={item.label} className="flex gap-4 group">
                <div className="w-12 h-12 bg-[#0d1b2a] flex items-center justify-center flex-shrink-0 group-hover:bg-[#c1121f] transition-colors">
                  <item.icon size={20} className="text-white" />
                </div>
                <div>
                  <div className="font-['Nunito_Sans'] text-gray-400 text-xs uppercase tracking-wider mb-1">{item.label}</div>
                  {item.href ? (
                    <a href={item.href} target={item.href.startsWith("http") ? "_blank" : undefined} rel="noopener noreferrer"
                      className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold hover:text-[#c1121f] transition-colors whitespace-pre-line">
                      {item.value}
                    </a>
                  ) : (
                    <div className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold whitespace-pre-line">{item.value}</div>
                  )}
                </div>
              </div>
            ))}

            <div className="pt-4">
              <Link href="/boka">
                <button className="btn-primary w-full flex items-center justify-center gap-2">
                  <Calendar size={18} />
                  Boka Tid Online
                </button>
              </Link>
            </div>
          </div>

          {/* Google Maps embed */}
          <div className="lg:col-span-2 h-96 lg:h-auto min-h-80">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2000!2d17.5547274!3d60.0227963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x465e2ce313d0e1e9%3A0x63690dc32fa0f60b!2sTibbles%20Bilverkstad%20AB-%20Bilxtra!5e0!3m2!1ssv!2sse!4v1700000000000!5m2!1ssv!2sse"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "380px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Tibbles Bilverkstad på kartan"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="bg-[#0a1520] py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
          <div className="flex items-center gap-2 mb-4">
              <img src={LOGO_URL} alt="Tibbles Bilverkstad" className="h-10 w-auto" />
            </div>
            <p className="font-['Nunito_Sans'] text-white/50 text-sm leading-relaxed">
              Professionell bilservice och reparationer i Björklinge. Vi tar hand om din bil med hög kvalitet och snabb service.
            </p>
          </div>
          <div>
            <h4 className="font-['Oswald'] text-white uppercase tracking-wider mb-4">Snabblänkar</h4>
            <div className="space-y-2">
              {["#tjanster", "#om-oss", "#galleri", "#recensioner", "#bilinformation", "#kontakt"].map((href, i) => (
                <a key={href} href={href} className="block font-['Nunito_Sans'] text-white/50 hover:text-white text-sm transition-colors">
                  {["Tjänster", "Om Oss", "Galleri", "Recensioner", "Bilinformation", "Kontakt"][i]}
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-['Oswald'] text-white uppercase tracking-wider mb-4">Kontakt</h4>
            <div className="space-y-3">
              <a href="tel:018-265-06-08" className="flex items-center gap-2 font-['Nunito_Sans'] text-white/50 hover:text-white text-sm transition-colors">
                <Phone size={14} className="text-[#c1121f]" /> 018 265 06 08
              </a>
              <a href="mailto:Tibblebilverkstad@gmail.com" className="flex items-center gap-2 font-['Nunito_Sans'] text-white/50 hover:text-white text-sm transition-colors">
                <Mail size={14} className="text-[#c1121f]" /> Tibblebilverkstad@gmail.com
              </a>
              <div className="flex items-start gap-2 font-['Nunito_Sans'] text-white/50 text-sm">
                <MapPin size={14} className="text-[#c1121f] mt-0.5 flex-shrink-0" />
                Bror Hjorths väg 2A, 743 64 Björklinge
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="Tibbles Bilverkstad" className="h-8 w-auto" />
            <p className="font-['Nunito_Sans'] text-white/30 text-sm">
              © 2025 Tibbles Bilverkstad AB. Org.nr: 559275-8741
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ─── Main Home Page ───────────────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Services />
      <About />
      <Gallery />
      <Reviews />
      <CarInformation />
      <FAQSection />
      <Contact />
      <Footer />
    </div>
  );
}
