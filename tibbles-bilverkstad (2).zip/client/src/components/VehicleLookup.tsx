import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, Search, AlertCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";

interface VehicleLookupProps {
  onVehicleFound?: (data: {
    make: string;
    model: string;
    year: string;
    color: string;
    fuelType: string;
  }) => void;
  onCarModelChange?: (carModel: string) => void;
}

export default function VehicleLookup({ onVehicleFound, onCarModelChange }: VehicleLookupProps) {
  const [regNumber, setRegNumber] = useState("");
  const [showResults, setShowResults] = useState(false);

  const lookupVehicle = trpc.vehicles.lookup.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success("Fordon hittades!");
        const carModel = `${data.make} ${data.model} (${data.year})`;
        if (onCarModelChange) {
          onCarModelChange(carModel);
        }
        if (onVehicleFound) {
          onVehicleFound({
            make: data.make,
            model: data.model,
            year: data.year,
            color: data.color,
            fuelType: data.fuelType,
          });
        }
        setShowResults(true);
      } else {
        toast.error(data.error || "Fordonet hittades inte");
        setShowResults(false);
      }
    },
    onError: (error) => {
      toast.error("Fel vid sökning: " + error.message);
      setShowResults(false);
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regNumber.trim()) {
      toast.error("Ange ett registreringsnummer");
      return;
    }
    lookupVehicle.mutate({ registrationNumber: regNumber });
  };

  const vehicleData = lookupVehicle.data;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
      <h3 className="font-['Oswald'] text-lg font-semibold text-[#0d1b2a] uppercase mb-4">
        Slå upp Fordon via Registreringsnummer
      </h3>

      <form onSubmit={handleSearch} className="flex gap-3 mb-4">
        <input
          type="text"
          value={regNumber}
          onChange={(e) => setRegNumber(e.target.value.toUpperCase())}
          placeholder="t.ex. ABC123"
          className="flex-1 border border-gray-300 px-4 py-2 focus:outline-none focus:border-[#c1121f]"
          maxLength={10}
        />
        <Button
          type="submit"
          disabled={lookupVehicle.isPending}
          className="bg-[#0d1b2a] hover:bg-[#c1121f] text-white font-['Oswald'] uppercase flex items-center gap-2 px-6"
        >
          {lookupVehicle.isPending ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Söker...
            </>
          ) : (
            <>
              <Search size={16} />
              Sök
            </>
          )}
        </Button>
      </form>

      <p className="font-['Nunito_Sans'] text-gray-600 text-sm mb-4">
        Ange ditt svenska registreringsnummer (t.ex. ABC123) för att automatiskt hämta fordonsinformation från Transportstyrelsen.
      </p>

      {showResults && vehicleData && vehicleData.success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3 mb-3">
            <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-['Oswald'] text-green-900 font-semibold">Fordon hittades!</h4>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            {vehicleData.make && (
              <div>
                <p className="font-['Nunito_Sans'] text-gray-600 text-xs uppercase">Märke</p>
                <p className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold">{vehicleData.make}</p>
              </div>
            )}
            {vehicleData.model && (
              <div>
                <p className="font-['Nunito_Sans'] text-gray-600 text-xs uppercase">Modell</p>
                <p className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold">{vehicleData.model}</p>
              </div>
            )}
            {vehicleData.year && (
              <div>
                <p className="font-['Nunito_Sans'] text-gray-600 text-xs uppercase">År</p>
                <p className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold">{vehicleData.year}</p>
              </div>
            )}
            {vehicleData.color && (
              <div>
                <p className="font-['Nunito_Sans'] text-gray-600 text-xs uppercase">Färg</p>
                <p className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold">{vehicleData.color}</p>
              </div>
            )}
            {vehicleData.fuelType && (
              <div>
                <p className="font-['Nunito_Sans'] text-gray-600 text-xs uppercase">Bränsle</p>
                <p className="font-['Nunito_Sans'] text-[#0d1b2a] font-semibold">{vehicleData.fuelType}</p>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              setRegNumber("");
              setShowResults(false);
            }}
            className="mt-4 text-sm text-green-600 hover:text-green-800 font-['Nunito_Sans'] underline"
          >
            Sök ett annat fordon
          </button>
        </div>
      )}

      {showResults && vehicleData && !vehicleData.success && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-['Oswald'] text-red-900 font-semibold">Sökningen misslyckades</h4>
              <p className="font-['Nunito_Sans'] text-red-800 text-sm mt-1">{vehicleData.error}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
