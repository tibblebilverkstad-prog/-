import { lookupVehicle } from './server/vehicle-lookup.ts';

async function test() {
  console.log('Testing vehicle lookup with LMM222...');
  const result = await lookupVehicle('LMM222');
  console.log('Result:', JSON.stringify(result, null, 2));
}

test().catch(console.error);
